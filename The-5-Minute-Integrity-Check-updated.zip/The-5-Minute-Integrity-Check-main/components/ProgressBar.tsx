
import React from 'react';
import { AppState } from '../types';

interface Props {
  current: AppState;
}

interface StepInfo {
  step: number;
  total: number;
  label: string;
}

const stepMap: Partial<Record<AppState, StepInfo>> = {
  [AppState.INTRO]:   { step: 1, total: 4, label: 'Introduction' },
  [AppState.PATTERN]: { step: 2, total: 4, label: 'Pattern Recognition' },
  [AppState.AUDIT]:   { step: 3, total: 4, label: 'Loneliness Audit' },
  [AppState.PIVOT]:   { step: 4, total: 4, label: 'Pivot Question' },
};

const ProgressBar: React.FC<Props> = ({ current }) => {
  const stepInfo = stepMap[current];
  if (!stepInfo) return null;

  const percent = Math.round((stepInfo.step / stepInfo.total) * 100);

  return (
    <div className="w-full max-w-2xl mb-4 px-1">
      <div className="flex justify-between items-center mb-2">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
          Step {stepInfo.step} of {stepInfo.total} — {stepInfo.label}
        </span>
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
          {percent}%
        </span>
      </div>
      <div className="w-full h-[3px] bg-gray-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-black transition-all duration-700 ease-out rounded-full"
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
