
import React, { useState } from 'react';
import { AssessmentData } from '../types';
import { getClarityInsight } from '../services/geminiService';

interface Props {
  data: AssessmentData;
}

interface RiskTier {
  label: string;
  color: string;
  bg: string;
  border: string;
  bar: string;
}

const getRiskTier = (score: number): RiskTier => {
  if (score <= 25) return {
    label: 'LOW',
    color: 'text-green-700',
    bg: 'bg-green-50',
    border: 'border-green-200',
    bar: 'bg-green-500'
  };
  if (score <= 50) return {
    label: 'MODERATE',
    color: 'text-yellow-700',
    bg: 'bg-yellow-50',
    border: 'border-yellow-200',
    bar: 'bg-yellow-500'
  };
  if (score <= 75) return {
    label: 'HIGH',
    color: 'text-orange-700',
    bg: 'bg-orange-50',
    border: 'border-orange-200',
    bar: 'bg-orange-500'
  };
  return {
    label: 'CRITICAL',
    color: 'text-red-700',
    bg: 'bg-red-50',
    border: 'border-red-200',
    bar: 'bg-red-600'
  };
};

const FinalCTA: React.FC<Props> = ({ data }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [emailSubmitted, setEmailSubmitted] = useState(false);

  // --- Risk Score calculation ---
  const patternScore = (data.patterns.filter(Boolean).length / 8) * 100;
  const auditValues = Object.values(data.audit) as number[];
  const auditAvg = auditValues.reduce((a, b) => a + b, 0) / auditValues.length;
  const auditVulnerability = ((5 - auditAvg) / 5) * 100;
  const riskScore = Math.round(patternScore * 0.6 + auditVulnerability * 0.4);
  const riskTier = getRiskTier(riskScore);

  const lowAuditKeys = (Object.entries(data.audit) as [string, number][])
    .filter(([_, v]) => v <= 2)
    .map(([k]) => k.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()));

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailSubmitted(true);
    setLoading(true);
    try {
      const text = await getClarityInsight(data);
      setInsight(text || 'Clarity achieved. Review your path forward.');
    } catch {
      setInsight('Review your audit results to identify your vulnerability vectors.');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: 'The 5-Minute Integrity Check',
        text: 'A private clarity assessment for high-functioning professionals.',
        url,
      });
    } else {
      navigator.clipboard.writeText(url).then(() => {
        alert('Link copied to clipboard.');
      });
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">

      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold tracking-tight">Executive Summary</h2>
        <div className="h-1 w-20 bg-black mx-auto"></div>
      </div>

      {/* Integrity Risk Score */}
      <div className={`border ${riskTier.border} ${riskTier.bg} p-6 rounded-sm space-y-4`}>
        <div className="flex justify-between items-center">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            Integrity Risk Score
          </p>
          <span className={`text-xs font-bold uppercase tracking-widest ${riskTier.color}`}>
            {riskTier.label}
          </span>
        </div>
        <div className="flex items-end gap-3">
          <p className={`text-6xl font-bold leading-none ${riskTier.color}`}>{riskScore}</p>
          <p className="text-sm text-gray-400 pb-1">/ 100</p>
        </div>
        <div className="w-full h-2 bg-white/60 rounded-full overflow-hidden">
          <div
            className={`h-full ${riskTier.bar} rounded-full transition-all duration-1000 ease-out`}
            style={{ width: `${riskScore}%` }}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="p-6 border border-gray-100 rounded-lg">
          <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">
            Coping Indicators
          </h3>
          <p className="text-2xl font-bold text-gray-900">
            {data.patterns.filter(p => p).length} / 8
          </p>
          <p className="text-xs text-gray-500 mt-1">Signs of sexual behavioral regulation</p>
        </div>
        <div className="p-6 border border-gray-100 rounded-lg">
          <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">
            Primary Vulnerability
          </h3>
          <p className="text-sm font-bold text-red-600 uppercase">
            {lowAuditKeys.length > 0 ? lowAuditKeys[0] : 'None Detected'}
          </p>
          <p className="text-xs text-gray-500 mt-1">Vector of emotional isolation</p>
        </div>
      </div>

      {/* Clarity Memo — Email Gate */}
      <div className="bg-gray-50 border border-gray-200 p-8 rounded-sm space-y-4">
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
          Clarity Memo
        </p>

        {!emailSubmitted ? (
          <div className="space-y-5">
            <p className="text-sm text-gray-700 leading-relaxed">
              Your personalized assessment is ready. Enter your email to unlock your private
              Clarity Memo — a direct, executive-level synthesis of what your results mean and
              what your next move is.
            </p>
            <form onSubmit={handleEmailSubmit} className="space-y-3">
              <input
                type="email"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-1 focus:ring-black focus:border-black outline-none transition-all text-sm"
                placeholder="Enter your email — private, never shared"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button
                type="submit"
                className="w-full bg-black text-white py-4 rounded font-bold text-xs uppercase tracking-widest hover:bg-gray-900 transition-colors"
              >
                Unlock My Clarity Memo
              </button>
            </form>
            <p className="text-center text-[10px] text-gray-400 uppercase tracking-widest">
              No spam. No public record. Confidential only.
            </p>
          </div>
        ) : loading ? (
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-gray-500 uppercase tracking-widest">
              Synthesizing your assessment...
            </p>
          </div>
        ) : (
          <div className="prose prose-sm text-gray-700 leading-relaxed font-serif italic text-lg">
            "{insight}"
          </div>
        )}
      </div>

      {/* CTA Section */}
      <div className="space-y-6 border-t border-gray-100 pt-10">
        <div className="space-y-3 text-center">
          <h3 className="text-2xl font-bold">You don't need motivation.</h3>
          <p className="text-xl font-light text-gray-600">You need structure.</p>
        </div>

        <div className="text-sm text-gray-600 space-y-3 leading-relaxed bg-black/5 p-6 rounded-lg text-center">
          <p>
            The <strong>Integrity Protocol</strong> is a structured weekly system built specifically
            for professionals who've tried willpower — and know it doesn't hold.
          </p>
          <p className="font-bold text-black uppercase tracking-tighter text-lg">
            Week 1 is free.
          </p>
        </div>

        <a
          href="https://integrity.scifsi.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full bg-black text-white text-center py-6 font-bold text-xl tracking-widest uppercase hover:bg-gray-800 transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1 active:translate-y-0"
        >
          Enter the Protocol →
        </a>

        {/* Secondary / Viral Share */}
        <div className="text-center space-y-2 pt-2">
          <p className="text-xs text-gray-400 uppercase tracking-widest">Not ready?</p>
          <button
            onClick={handleShare}
            className="text-xs font-bold text-gray-500 hover:text-black transition-colors uppercase tracking-widest underline underline-offset-4"
          >
            Forward this to a man who is →
          </button>
        </div>

        <p className="text-center text-[10px] text-gray-400 uppercase tracking-[0.2em] pt-4">
          Strictly Confidential • No data persistent after session close
        </p>
      </div>
    </div>
  );
};

export default FinalCTA;
