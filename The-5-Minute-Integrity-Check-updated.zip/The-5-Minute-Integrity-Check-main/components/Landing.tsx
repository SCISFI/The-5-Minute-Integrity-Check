
import React from 'react';

interface Props {
  onStart: () => void;
}

const Landing: React.FC<Props> = ({ onStart }) => {
  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="space-y-6">
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
          SC-IFSI • Private Integrity Instrument
        </p>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-gray-900 leading-tight">
          You've managed everything.
          <br />
          <span className="italic font-light">Except this.</span>
        </h1>
        <p className="text-base text-gray-500 font-light leading-relaxed max-w-md">
          A 5-minute private assessment for high-functioning professionals.
          No account. No record. No one sees this but you.
        </p>
      </div>

      <div className="space-y-3 text-sm text-gray-600 border-l-4 border-black pl-5 py-1">
        <p>You perform under pressure. You hold things together. You meet every expectation.</p>
        <p>And still — there's a pattern running in the background that doesn't match the man others see.</p>
      </div>

      <div className="space-y-4">
        <button
          onClick={onStart}
          className="w-full bg-black text-white py-5 rounded font-bold text-sm uppercase tracking-widest hover:bg-gray-900 transition-colors"
        >
          Begin Assessment
        </button>
        <p className="text-center text-[10px] text-gray-400 uppercase tracking-widest">
          Private. Anonymous. Takes 5 minutes.
        </p>
      </div>
    </div>
  );
};

export default Landing;
